create trigger WARNWEATHERS_TRIGGER
	before insert
	on WARNWEATHERS
	for each row
BEGIN
    SELECT seq_WarnWeathers_wno.nextval
    INTO :new.wno
    FROM sys.dual;
  END;